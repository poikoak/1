#include <iostream>
#include <io.h>

/**
 * Пользователь вводит путь к папке и маску файлов, программа подсчитывает общий размер
 * файлов с указанной маской.
 * */

int main() {
    const unsigned STR_LENGTH = 64;

    char *path = new char[STR_LENGTH], *mask = new char[STR_LENGTH];

    std::cout << "Type a path!" << std::endl;
    std::cin.getline(path, STR_LENGTH);

    std::cout << "Type a mask!" << std::endl;
    std::cin.getline(mask, STR_LENGTH);

    // переменная, хранящая информацию об одном файле
    _finddata_t c_file;

    // адрес списка найденных файлов
    long hFile;
    long long filesSize = 0;

    // найти файлы по маске и вернуть адрес списка найденных файлов и информацию о первом файле

    hFile = _findfirst(strcat(path, mask), &c_file);

    // если файл является папкой
    if (c_file.attrib & _A_SUBDIR)
        std::cout << c_file.name << "   " << "<DIR>" << std::endl;
    else {
        std::cout << c_file.name << "   " << c_file.size << std::endl;
        filesSize += c_file.size;
    }

    // цикл для получения информации об остальных найденных файлах
    while (_findnext(hFile, &c_file) == 0) {
        if (c_file.attrib & _A_SUBDIR)
            std::cout << c_file.name << "   " << "<DIR>" << std::endl;
        else {
            std::cout << c_file.name << "   " << c_file.size << std::endl;
            filesSize += c_file.size;
        }
    }

    // освободить память от списка найденных файлов
    _findclose(hFile);

    std::cout << "-------------------------------------" << std::endl;
    std::cout << "Files size: " << filesSize << std::endl;

    return 0;
}