#include <iostream>

/**
 * Пользователь вводит массив из 5 чисел, рекурсивная функция выясняет, все ли числа в массиве
 * делятся на 2 и на 3 без остатка. (рекурсивная функция)
 * */

bool isDivideWithoutRem(const int *arr, const unsigned &count);


int main() {
    int arr[5];

    std::cout << "Type an array!" << std::endl;
    for (int &i : arr)
        std::cin >> i;

    std::cout << isDivideWithoutRem(arr, 5) << std::endl;

    return 0;
}

bool isDivideWithoutRem(const int *arr, const unsigned &count) {
    if (count == 1)
        return (*arr % 2 == 0) && (*arr % 3 == 0);

    return isDivideWithoutRem(arr + 1, count - 1) && (*arr % 2 == 0) && (*arr % 3 == 0);
}
