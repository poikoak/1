#include <iostream>

/**
 * Рекурсивная функция принимает 2 строки и выясняет равны ли они.
 * */

bool isEqualsStr(const char *str1, const char *str2);

int main() {
    const unsigned STR_LENGTH = 256;

    char *str1 = new char[STR_LENGTH], *str2 = new char[STR_LENGTH];

    std::cout << "Type a string1!" << std::endl;
    std::cin.getline(str1, STR_LENGTH);

    std::cout << "Type a string2!" << std::endl;
    std::cin.getline(str2, STR_LENGTH);

    std::cout << isEqualsStr(str1, str2);

    return 0;
}

bool isEqualsStr(const char *str1, const char *str2) {
    // Это проверку делаю на случай, если длина строк не равна. Если бы я оставил только бы второе условие (*str1 == 0),
    // то могла бы быть ситуация что я сравниваю символ одной строки с мусором, который, по идеи может совпасть с
    // проверяемым символом.
    if ((*str1 == 0 && *str2 != 0) || (*str1 != 0 && *str2 == 0))
        return false;
    else if (*str1 == 0)
        return *str1 == *str2;

    return isEqualsStr(str1 + 1, str2 + 1) && *str1 == *str2;
}
