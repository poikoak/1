#include <iostream>

/**
 * Пользователь вводит двумерный динамический массив,
 * программа находит сумму нечётных отрицательных элементов. (рекурсивная функция)
 * */

void printArray(int **arr, const unsigned &rowCount, const unsigned &columnCount);

int sumOddAndNegativeNum(int **arr, const unsigned &rowCount, const unsigned &columnCount, const unsigned &i = 0);

int sumOddAndNegativeNum1(int **arr, const unsigned &rowCount, const unsigned &columnCount);

int recSumOddAndNegativeNum(const int *arr, const unsigned &size);

int main() {
    int **arr;
    int rowCount, columnCount;

    std::cout << "Type a row count!" << std::endl;
    std::cin >> rowCount;
    if (rowCount <= 0) {
        std::cout << "Invalid row count!" << std::endl;
        return 0;
    }

    std::cout << "Type a column count!" << std::endl;
    std::cin >> columnCount;
    if (columnCount <= 0) {
        std::cout << "Invalid column count!" << std::endl;
        return 0;
    }

    // Первый вариант создания двумерного массива
    /*arr = new int *[rowCount];
    for (int i = 0; i < rowCount; ++i)
        arr[i] = new int[columnCount];*/

    // Второй вариант. Тут я выделяю память только для массива указателей и первому указателю из этого массива
    // присваиваю адрес памяти, где будут храниться все элементы массива. Далее для каждого указателя из массива указателей
    // присваиваю адрес соответсвующей ячейки.
    arr = new int *[rowCount];
    *arr = new int[rowCount * columnCount];
    for (int i = 1; i < rowCount; ++i)
        arr[i] = *arr + i * columnCount;


    std::cout << "Type an array!" << std::endl;
    for (int i = 0; i < rowCount; ++i) {
        for (int j = 0; j < columnCount; ++j) {
            std::cin >> arr[i][j];
        }
    }

    std::cout << "Array:" << std::endl;
    printArray(arr, rowCount, columnCount);

    std::cout << sumOddAndNegativeNum1(arr, rowCount, columnCount) << std::endl;

    return 0;
}

void printArray(int **arr, const unsigned &rowCount, const unsigned &columnCount) {
    for (int i = 0; i < rowCount; ++i) {
        for (int j = 0; j < columnCount; ++j) {
            std::cout << arr[i][j] << "\t";
        }
        std::cout << std::endl;
    }
}

// Вариант функции для первого варианта создания двумерного массива. Хотя работать будет и со вторым вариантом.
int sumOddAndNegativeNum(int **arr, const unsigned &rowCount, const unsigned &columnCount, const unsigned &i) {
    int res = 0;

    // Тут подсчитывается сумма строки исходя из словия задачи
    if (i < columnCount - 1)
        res = sumOddAndNegativeNum(arr, rowCount, columnCount, i + 1);

    // Тут суммируются все строки
    if (rowCount > 1 && i == 0)
        res += sumOddAndNegativeNum(arr + 1, rowCount - 1, columnCount, 0);

    return res + ((*(*arr + i) % 2 != 0 && *(*arr + i) < 0) ? *(*arr + i) : 0);
}

// Вариант функции для второго варианта создания массива.
int sumOddAndNegativeNum1(int **arr, const unsigned &rowCount, const unsigned &columnCount) {
    return recSumOddAndNegativeNum(*arr, rowCount * columnCount);
}

int recSumOddAndNegativeNum(const int *arr, const unsigned &size) {
    int res = 0;

    if (size > 1)
        res = recSumOddAndNegativeNum(arr + 1, size - 1);

    return res + ((*arr % 2 != 0 && *arr < 0) ? *arr  : 0);
}

