#include <iostream>

/**
 * Рекурсивная функция принимает строку и букву и подсчитывает сколько раз буква встречается
 * в строке.
 * */

unsigned numberOfOccurrences(const char *str, const char &sym);

int main() {
    const unsigned STR_LENGTH = 256;

    char *str = new char[STR_LENGTH];
    char sym;

    std::cout << "Type a string!" << std::endl;

    std::cin.getline(str, STR_LENGTH);

    std::cout << "Type a symbol!" << std::endl;

    std::cin >> sym;

    std::cout << numberOfOccurrences(str, sym) << std::endl;

    return 0;
}

unsigned numberOfOccurrences(const char *str, const char &sym) {
    if (*str == 0)
        return (*(str - 1) == sym) ? 1 : 0;

    return numberOfOccurrences(str + 1, sym) + ((*(str - 1) == sym) ? 1 : 0);
}
