#pragma once

#include <list>
#include "WordsFrequencyDictionary.h"

using namespace std;

class ListFrequencyDictionary: public WordsFrequencyDictionary
{
	list<Word*> words;

public:
	ListFrequencyDictionary() : WordsFrequencyDictionary("ListFrequencyDictionary") {}

	void Add(string word);
	size_t getSize();
	void save(ostream& os);
};

