#include "MapFrequencyDictionary.h"

void MapFrequencyDictionary::Add(string word)
{
	if (words.find(word) != words.end())
		words[word]++;
	else
		words[word] = 1;
}

size_t MapFrequencyDictionary::getSize()
{
	return words.size();
}

void MapFrequencyDictionary::save(ostream& os)
{
	for (map<string, int>::iterator i = words.begin(); i != words.end(); i++) {
		os << (*i).first << ":\t" << (*i).second << "\n";
	}
}
