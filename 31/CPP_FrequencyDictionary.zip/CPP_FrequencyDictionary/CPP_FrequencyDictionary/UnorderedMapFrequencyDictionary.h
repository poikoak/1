#pragma once

#include <unordered_map>
#include "WordsFrequencyDictionary.h"

using namespace std;

class UnorderedMapFrequencyDictionary : public WordsFrequencyDictionary
{
	unordered_map<string, int> words;

public:
	UnorderedMapFrequencyDictionary() : WordsFrequencyDictionary("UnorderedMapFrequencyDictionary") {}

	void Add(string word);
	size_t getSize();
	void save(ostream& os);
};

