#include "VectorFrequencyDictionary.h"

void VectorFrequencyDictionary::Add(string word)
{
	//list<Word*>::iterator it;
	for (auto it = words.begin(); it != words.end(); ++it) {
		if (word.compare((*it)->word) == 0)
		{
			(*it)->frequency++;
			return;
		}
	}
	words.push_back(new Word(word));
}

size_t VectorFrequencyDictionary::getSize()
{
	return words.size();
}

void VectorFrequencyDictionary::save(ostream& os)
{
	for (auto it = words.begin(); it != words.end(); it++) {
		os << (*it)->word << ":\t" << (*it)->frequency << "\n";
	}
}
