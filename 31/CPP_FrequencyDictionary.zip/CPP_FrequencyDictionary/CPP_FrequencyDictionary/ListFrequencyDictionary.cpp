#include "ListFrequencyDictionary.h"

void ListFrequencyDictionary::Add(string word)
{
	//list<Word*>::iterator it;
	for (auto it = words.begin(); it != words.end(); ++it) {
		if (word.compare((*it)->word) == 0)
		{
			(*it)->frequency++;
			return;
		}
	}
	words.push_back(new Word(word));
}

size_t ListFrequencyDictionary::getSize()
{
	return words.size();
}

void ListFrequencyDictionary::save(ostream& os)
{
	for (auto it = words.begin(); it != words.end(); it++) {
		os << (*it)->word << ":\t" << (*it)->frequency << "\n";
	}
}
