#include <iostream>
#include <fstream>
#include <map>
#include "WordsFrequencyDictionary.h"
#include "VectorFrequencyDictionary.h"
#include "ListFrequencyDictionary.h"
#include "MapFrequencyDictionary.h"
#include "UnorderedMapFrequencyDictionary.h"
#include "WordsDictionaryMaker.h"

using namespace std;

void main()
{
	const string text_sample = "eng_text.txt";

	/*WordsDictionaryMaker maker(new UnorderedMapFrequencyDictionary());
	maker.Process("eng_text.txt");
	maker.Save(maker.GetDictionary()->GetTitle() + "_result.txt");*/

	WordsFrequencyDictionary* dicts[] = {
		new MapFrequencyDictionary(),
		new UnorderedMapFrequencyDictionary(),
		new VectorFrequencyDictionary(),
		new ListFrequencyDictionary()
	};

	WordsDictionaryMaker maker(nullptr);

	for (int i = 0; i < 4; i++)
	{
		maker.SetDictionary(dicts[i]);
		maker.Process(text_sample);
		maker.Save(maker.GetDictionary()->GetTitle() + "_result.txt");
	}
}