#include "UnorderedMapFrequencyDictionary.h"

void UnorderedMapFrequencyDictionary::Add(string word)
{
	if (words.find(word) != words.end())
		words[word]++;
	else
		words[word] = 1;
}

size_t UnorderedMapFrequencyDictionary::getSize()
{
	return words.size();
}

void UnorderedMapFrequencyDictionary::save(ostream& os)
{
	for (unordered_map<string, int>::iterator i = words.begin(); i != words.end(); i++) {
		os << (*i).first << ":\t" << (*i).second << "\n";
	}
}
