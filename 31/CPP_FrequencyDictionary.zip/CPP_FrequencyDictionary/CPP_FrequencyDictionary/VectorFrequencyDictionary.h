#include <vector>
#include "WordsFrequencyDictionary.h"

using namespace std;

class VectorFrequencyDictionary : public WordsFrequencyDictionary
{
	vector<Word*> words;

public:
	VectorFrequencyDictionary() : WordsFrequencyDictionary("VectorFrequencyDictionary") {}
	void Add(string word);
	size_t getSize();
	void save(ostream& os);
};