#pragma once
#include "LuckyCriteria.h"
class LuckySequence :
    public LuckyCriteria
{

    int* sequences;
  int seqSize;
public:
    LuckySequence(int length, int seqSize, int seq[]);
    void Check(LuckyCriteria ls);
 
};
   


