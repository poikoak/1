﻿// GetLucky.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include "pch.h"
#include <iostream>
#include "LuckyCriteria.h"
#include "LuckySequence.h"
#include "LuckySums.h"

bool luckyrule0(int x) {
    int a = 0, b = 0, c = 0, d = 0, e = 0, f = 0;
    a = x % 10;
    b = (x / 10) % 10;
    c = (x / 100) % 10;
    d = (x / 1000) % 10;
    e = (x / 10000) % 10;
    f = (x / 100000) % 10; 
    
    return (a + b + c == e + d + f);
}


bool luckyrule1(int x) {
    int a = 0, b = 0, c = 0, d = 0, e = 0, f = 0;
    a = x % 10;
    b = (x / 10) % 10;
    c = (x / 100) % 10;
    d = (x / 1000) % 10;
    e = (x / 10000) % 10;
    f = (x / 100000) % 10;

    return (((a == f) && (b==e)) && (c==d) );
}

bool luckyrule2(int x) {
    int a = 0, b = 0, c = 0, d = 0, e = 0, f = 0;
    a = x % 10;
    b = (x / 10) % 10;
    c = (x / 100) % 10;
    d = (x / 1000) % 10;
    e = (x / 10000) % 10;
    f = (x / 100000) % 10;

    return (((a ==d ) && (b == e)) && (c == f));

}
bool luckyrule3(int x) {
    int a = 0, b = 0, c = 0, d = 0, e = 0, f = 0;
    a = x % 10;
    b = (x / 10) % 10;
    c = (x / 100) % 10;
    d = (x / 1000) % 10;
    e = (x / 10000) % 10;
    f = (x / 100000) % 10;

    return ((a == a) && (b == a + 1) && (c == a + 2) && (d == a + 3) && (e == a + 4) && (f = a + 5));
}

bool luckyrule5(int x) {
    int a = 0, b = 0, c = 0, d = 0, e = 0, f = 0;
    a = x % 10;
    b = (x / 10) % 10;
    c = (x / 100) % 10;
    d = (x / 1000) % 10;
    e = (x / 10000) % 10;
    f = (x / 100000) % 10;

    return ((a == a) && (b == a - 1) && (c == a - 2) && (d == a - 3) && (e == a - 4) && (f = a - 5));
}

bool luckyrule4(int x) {
    int a = 0, b = 0, c = 0, d = 0, e = 0, f = 0;
    a = x % 10;
    b = (x / 10) % 10;
    c = (x / 100) % 10;
    d = (x / 1000) % 10;
    e = (x / 10000) % 10;
    f = (x / 100000) % 10;

    return (((a==c)&& (c==e)) && ((b == d) && (d == f)));
}

int main()
{
    // сделал покороче, чтобы меньше считать
    int seq[2]= { 777, 888 };
    LuckySequence ls= LuckySequence(1000, 2, seq);
    ls.Check(ls);
    cout << "Count of lucky numbers " << ls.GetLucky();
    ls.Save("test.txt");
   LuckySums ls2 = LuckySums(1000000);
   int b = 0;
   cout << endl << " Write for  0 - simple example, 1 - 123321, 2 -  123123, 3 - 123456, 4 - 101010, 5 - 987654" << endl;
   cin >> b;
   if (b == 0) {
       ls2.Check(ls2, luckyrule0);
   } else if (b == 1) {
       ls2.Check(ls2, luckyrule1);
   }
   else if (b == 2) {
       ls2.Check(ls2, luckyrule2);
   }
   else if (b == 3) {
       ls2.Check(ls2, luckyrule3);
   }
   else if (b == 4) {
       ls2.Check(ls2, luckyrule4);
   }
   else if (b == 5) {
       ls2.Check(ls2, luckyrule5);
   }


    cout << "Count of lucky numbers by rule " << ls2.GetLucky();
    ls2.Save("test2.txt");
 


    //либо же через указатель на функцию





}

