#include "pch.h"
#include "LuckySums.h"
#include <iostream>
LuckySums::LuckySums(int length) : LuckyCriteria(length)
{

 }
void LuckySums::Check(LuckyCriteria ls, bool luckyrule(int))
{
    lucky = 0;
  /*  int a = 0, b = 0, c = 0, d = 0, e = 0, f = 0;*/

    for (int i = 0; i < size; i++) {
     /*   a = i % 10;
        b = (i / 10) % 10;
        c = (i / 100) % 10;
        d = (i / 1000) % 10;
        e = (i / 10000) % 10;
        f = (i / 100000) % 10;*/
       // if ((a + b + c == e + d + f)) {
            if (luckyrule(i)) {
            numbers[lucky] = i;
            lucky++;

           // cout << i << endl;
        }
     
    }
}
