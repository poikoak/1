#include "pch.h"
#include <iostream>
#include "LuckyCriteria.h"
using namespace std;
LuckyCriteria::LuckyCriteria(int length)
{
	size = length;
	numbers = new unsigned int[size];
	//sequences=new int

}

void LuckyCriteria::Check(LuckyCriteria ls, bool luckyrule(int))
{

}



void LuckyCriteria::Save(const char* filename)
{
	
	FILE* targetFile = fopen(filename, "a");




	fprintf(targetFile, "Numbers: %d\\\r\n", (unsigned int)size);
	fprintf(targetFile, "Max number: %d\\\r\n", (unsigned int)lucky);

	for (size_t i = 0; i < lucky; i++)
	{
		fprintf(targetFile, "%d\\\r\n", numbers[i]);
	}

	fclose(targetFile);


}
