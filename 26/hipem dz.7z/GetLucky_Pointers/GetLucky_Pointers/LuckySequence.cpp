#include "pch.h"
#include "LuckySequence.h"
#include "LuckyCriteria.h"
#include <iostream>
using namespace std;
LuckySequence::LuckySequence(int length, int seqSize, int seq[]) : LuckyCriteria(length)
{
	sequences = new int[seqSize];
	sequences = seq;

}

void LuckySequence::Check(LuckyCriteria ls)
{
	lucky = 0;

	bool result = false;
	int seqn = 0; 
	


		for (int i = 0; i < size - 1; i++) {

			if (i == sequences[lucky]) result = true;


			
			if (result == true) {
				numbers[lucky] = i;
				//cout << i;
				//cout << numbers[lucky];
				lucky++;
				result = false;
			}
			//cout << numbers[lucky] << endl;
			//cout << lucky;
		}


}


