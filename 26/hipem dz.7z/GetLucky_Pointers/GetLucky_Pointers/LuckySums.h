#pragma once
#include "LuckyCriteria.h"
class LuckySums :
    public LuckyCriteria
{
    //int* sums;
public:
    LuckySums(int length);
    void Check(LuckyCriteria ls, bool luckyrule(int));


};

