#pragma once

using namespace std;
//typedef void (LuckySequence::* check_handler) (LuckyCriteria ls);
//typedef void (LuckySums::* check_handler)();
class LuckyCriteria
{
protected:
	unsigned int *numbers;
	unsigned int size;
	unsigned int lucky;

public:
	LuckyCriteria(int length);
	~LuckyCriteria() { //delete[] numbers; 
	}

	virtual void Check(LuckyCriteria ls, bool luckyrule(int));
	unsigned int GetLucky() { return lucky; }
	//typedef double (*func_type)(LuckyCriteria ls);

	//LuckyCriteria Check2(LuckyCriteria ls, check_handler fn);
	void Save(const char* filename);
};

