#pragma once
template <typename T>
class Queue
{
	T* queue;;
	int max;
	int top;
	int bot; // bottom
	int current;
public:
	Queue(int size = 10);

	int Length();
	void Enqueue(T x);
	void Dequeue();
	T Peek();

};

template<typename T>
inline Queue<T>::Queue(int size)
{
	queue = new T[size];
	max = size;
	top = 0;
	bot = -1;
	current = 0;
}

template<typename T>
inline int Queue<T>::Length()
{
	return current;
}

template<typename T>
inline void Queue<T>::Enqueue(T x)
{
	if (Length() == max) {
		throw exception("Overflow");
	}
	bot = (bot + 1) % max;
	queue[bot] = x;
	current++;
}

template<typename T>
inline void Queue<T>::Dequeue()
{
	if (Length() == 0) {
		throw exception("Underflow");
	}
	top = (top + 1) % max;
	
	current--;
}

template<typename T>
inline T Queue<T>::Peek()
{
	if (Length() == 0) {
		throw exception("Underflow");
	}

	return queue[top];
}
