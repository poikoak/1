#pragma once
#include "pch.h"

using namespace std;
template <typename T>
class Stack
{

T* stack;
unsigned int size;
unsigned int MaxSize;
public:

	Stack(int size);
	~Stack() {
		delete[] stack;
	};

	void Push( T x);
	T Pop();
	T Peek();
	unsigned int Length();

	


};

template<typename T>
inline Stack<T>::Stack(int maxsize)
{
	size = -1;
	MaxSize = maxsize;

	// ��������� ������ ��� ������ ����������
	stack = new T [MaxSize];
}

template<typename T>
inline void Stack<T>::Push(T x)
{
	if (size == MaxSize) {
		throw exception("Stack overflow");
		//cout << "\nStack overflow\n";
		//abort();
	}
	else {
		stack[++size] = x;

	}

}

template<typename T>
inline T Stack<T>::Pop()
{
	if (size == -1) {
		cout << "Stack underflow";
		abort();
	} else{
		return stack[size--];
	}

}

template<typename T>
inline T Stack<T>::Peek()
{
	if (!(size == -1)) {
		return stack[size];
	}
	else {
		cout << "empty";
		abort();
	}
}

template<typename T>
inline unsigned int Stack<T>::Length()
{
	return size+1;
}



